function firstClick() {
    var x = document.getElementById("qu");
    x.innerHTML = "There are many travelling places. Hikkaduwa Beach, Mirissa Beach, Galle Fort, Japanese Peace Pagoda are some of them"
}

function secondClick() {
    var x = document.getElementById("qu");
    x.innerHTML = "There are many travelling places. Koneshwaram Temple, Nila weli Beach, Arugam Bay, Passi kuda Beach, Pigon Island are some of them"
}

function thirdClick() {
    var x = document.getElementById("qu");
    x.innerHTML = "There are many travelling places. Beruwala Point, Saint Sebastian Canel, Beira Lake, Gin River, Colombo Habour are some of them"
}

function forthClick() {
    var x = document.getElementById("qu");
    x.innerHTML = "There are many travelling places. Pinnawala elephant Ophanage, Sri Padaya, Udawalawa elephant Ophanage, Udawalawa National Park are some of them."
}

function fifthClick() {
    var x = document.getElementById("qu");
    x.innerHTML = "There are many travelling places. Temple of the tooth, Horton Plains, Sigiriya, Pidurangala Rock, Bahirawa Kanda Temple are some of them."
}

function sixthClick() {
    var x = document.getElementById("qu");
    x.innerHTML = "There are many travelling places. Nallur Kovil, Mannar Island, Naga Poshini Ambal Kovil, Nagadeepa Purana Wiharaya are some of them."
}

function seventhClick() {
    var x = document.getElementById("qu");
    x.innerHTML = "There are many travelling places. Girithale Colony, Namal wewa, Basawakkulama, Mihinthale, Moragaswewa, Kaludiya Pokuna are some of them."
}

function eightthClick() {
    var x = document.getElementById("qu");
    x.innerHTML = "There are many travelling places. Kudawa Beach, Ridi Wiharaya, Munneshwaram Hindu temple, Dutch fort of Kalpitiya are some of them."
}

function nightClick() {
    var x = document.getElementById("qu");
    x.innerHTML = "There are many travelling places. Ella Rock, Lipton's Seat, Kirigalpoththa Hike, Ella Spike Garden, Rawana waterfall are some of them."
}

