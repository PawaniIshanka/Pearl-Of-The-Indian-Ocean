function funcClick() {
    var x = document.getElementById("feed");
    x.innerHTML = "Wooooow..., Oh!! Really... I am very happy."
}

function funClick() {
    var x = document.getElementById("feed");
    x.innerHTML = "Oops..., Oh!! I am very sad."
}